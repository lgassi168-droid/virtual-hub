import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import {
  FlaskConical,
  Clock,
  Sparkles,
  ListChecks,
  Plus,
  Trash2,
  X,
  Cpu,
  Wifi,
  Bot,
  Terminal,
  Zap,
} from 'lucide-react'
import './Dashboard.css'

type LabKey = 'iot' | 'network' | 'robotics' | 'assembly' | 'circuit'
type Status = 'progress' | 'testing' | 'completed'

interface Project {
  id: string
  name: string
  lab: LabKey
  status: Status
  hoursAdded?: number
}

interface ActivityEntry {
  id: string
  name: string
  time: string
}

const LABS: Record<LabKey, { label: string; path: string; icon: typeof Cpu }> = {
  iot: { label: 'Engineering & IoT Lab', path: '/lab/iot', icon: Cpu },
  network: { label: 'Network & Cyber Lab', path: '/lab/network', icon: Wifi },
  robotics: { label: 'Robotics & Automation Lab', path: '/lab/robotics', icon: Bot },
  assembly: { label: 'Assembly Lab', path: '/lab/assembly', icon: Terminal },
  circuit: { label: 'Circuit Lab', path: '/lab/circuit', icon: Zap },
}

const STATUS_LABEL: Record<Status, string> = {
  progress: 'In Progress',
  testing: 'Testing',
  completed: 'Completed',
}

const STATUS_ORDER: Status[] = ['progress', 'testing', 'completed']

const SEED_SUGGESTIONS: { name: string; lab: LabKey }[] = [
  { name: 'IoT Motion Sensor', lab: 'iot' },
  { name: 'ESP32 Smart Home', lab: 'iot' },
  { name: 'Line-Following Robot', lab: 'robotics' },
  { name: 'Assembly Calculator', lab: 'assembly' },
  { name: 'RC Filter Simulation', lab: 'circuit' },
  { name: 'Router Topology Build', lab: 'network' },
]

const STORAGE = {
  projects: 'vh_dash_projects',
  aiReviews: 'vh_dash_ai_reviews',
  simHours: 'vh_dash_sim_hours',
  activity: 'vh_dash_activity',
}

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}

export default function Dashboard() {
  const navigate = useNavigate()

  const [projects, setProjects] = useState<Project[]>(() => load(STORAGE.projects, []))
  const [aiReviews, setAiReviews] = useState<number>(() => load(STORAGE.aiReviews, 0))
  const [simHours, setSimHours] = useState<number>(() => load(STORAGE.simHours, 0))
  const [activity, setActivity] = useState<ActivityEntry[]>(() => load(STORAGE.activity, []))

  const [showAddModal, setShowAddModal] = useState(false)
  const [newName, setNewName] = useState('')
  const [newLab, setNewLab] = useState<LabKey>('iot')

  useEffect(() => {
    localStorage.setItem(STORAGE.projects, JSON.stringify(projects))
  }, [projects])
  useEffect(() => {
    localStorage.setItem(STORAGE.aiReviews, JSON.stringify(aiReviews))
  }, [aiReviews])
  useEffect(() => {
    localStorage.setItem(STORAGE.simHours, JSON.stringify(simHours))
  }, [simHours])
  useEffect(() => {
    localStorage.setItem(STORAGE.activity, JSON.stringify(activity))
  }, [activity])

  const completedCount = useMemo(
    () => projects.filter((p) => p.status === 'completed').length,
    [projects]
  )
  const inProgressCount = projects.length - completedCount

  const suggestions = useMemo(
    () =>
      SEED_SUGGESTIONS.filter(
        (s) => !projects.some((p) => p.name === s.name && p.lab === s.lab)
      ),
    [projects]
  )

  const activeProject = useMemo(
    () => projects.find((p) => p.status !== 'completed'),
    [projects]
  )

  function addProject(name: string, lab: LabKey) {
    const trimmed = name.trim()
    if (!trimmed) return
    const id = Date.now().toString() + Math.floor(Math.random() * 1000)
    setProjects((prev) => [{ id, name: trimmed, lab, status: 'progress' }, ...prev])
  }

  function handleAddSubmit(e: React.FormEvent) {
    e.preventDefault()
    addProject(newName, newLab)
    setNewName('')
    setNewLab('iot')
    setShowAddModal(false)
  }

  function addSuggestion(name: string, lab: LabKey) {
    addProject(name, lab)
  }

  function cycleStatus(index: number) {
    setProjects((prev) => {
      const updated = [...prev]
      const proj = { ...updated[index] }
      const wasCompleted = proj.status === 'completed'
      const next = STATUS_ORDER[(STATUS_ORDER.indexOf(proj.status) + 1) % STATUS_ORDER.length]
      const willBeCompleted = next === 'completed'

      if (willBeCompleted && !wasCompleted) {
        const hoursAdded = Math.floor(Math.random() * 2) + 1
        proj.hoursAdded = hoursAdded
        setAiReviews((r) => r + 1)
        setSimHours((h) => h + hoursAdded)
        setActivity((a) =>
          [{ id: proj.id, name: proj.name, time: new Date().toLocaleString() }, ...a].slice(0, 4)
        )
      } else if (wasCompleted && !willBeCompleted) {
        const hoursAdded = proj.hoursAdded || 1
        setAiReviews((r) => Math.max(0, r - 1))
        setSimHours((h) => Math.max(0, h - hoursAdded))
        setActivity((a) => a.filter((x) => x.id !== proj.id))
      }

      proj.status = next
      updated[index] = proj
      return updated
    })
  }

  function deleteProject(index: number) {
    setProjects((prev) => {
      const proj = prev[index]
      if (proj.status === 'completed') {
        setActivity((a) => a.filter((x) => x.id !== proj.id))
        setAiReviews((r) => Math.max(0, r - 1))
        setSimHours((h) => Math.max(0, h - (proj.hoursAdded || 1)))
      }
      return prev.filter((_, i) => i !== index)
    })
  }

  return (
    <main className="dash">
      <section className="dash-hero">
        <div className="dash-hero-text">
          <p className="dash-eyebrow">DASHBOARD</p>
          <h1 className="dash-headline display">Welcome back</h1>
          <p className="dash-sub">
            Build, test, and track your engineering lab projects — with real-time AI feedback
            whenever you need it.
          </p>
          {activeProject && (
            <button
              className="dash-btn-cta"
              onClick={() => navigate(LABS[activeProject.lab].path)}
            >
              Continue "{activeProject.name}" →
            </button>
          )}
        </div>
      </section>

      <section className="dash-cards" aria-label="Dashboard statistics">
        <div className="dash-card">
          <FlaskConical className="dash-card-icon" size={22} />
          <h3>Completed</h3>
          <p className="dash-card-num">{completedCount}</p>
        </div>
        <div className="dash-card">
          <ListChecks className="dash-card-icon" size={22} />
          <h3>In Progress</h3>
          <p className="dash-card-num">{inProgressCount}</p>
        </div>
        <div className="dash-card">
          <Sparkles className="dash-card-icon" size={22} />
          <h3>AI Reviews</h3>
          <p className="dash-card-num">{aiReviews}</p>
        </div>
        <div className="dash-card">
          <Clock className="dash-card-icon" size={22} />
          <h3>Simulation Time</h3>
          <p className="dash-card-num">{simHours}h</p>
        </div>
      </section>

      <section className="dash-bottom">
        <div className="dash-projects">
          <div className="dash-section-header">
            <h2>My Projects</h2>
            <button className="dash-add-btn" onClick={() => setShowAddModal(true)}>
              <Plus size={15} /> Add Project
            </button>
          </div>

          {projects.length === 0 ? (
            <p className="dash-empty">No projects yet — add one or pick a suggestion below.</p>
          ) : (
            <div className="dash-project-list">
              {projects.map((p, i) => {
                const lab = LABS[p.lab]
                const Icon = lab.icon
                return (
                  <div className="dash-project" key={p.id}>
                    <Icon size={16} className="dash-project-icon" />
                    <span className="dash-project-name" onClick={() => navigate(lab.path)}>
                      {p.name}
                    </span>
                    <span className="dash-lab-tag">{lab.label}</span>
                    <span
                      className={`dash-status dash-status-${p.status}`}
                      onClick={() => cycleStatus(i)}
                      title="Click to change status"
                    >
                      {STATUS_LABEL[p.status]}
                    </span>
                    <button
                      className="dash-delete-btn"
                      onClick={() => deleteProject(i)}
                      aria-label={`Delete ${p.name}`}
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                )
              })}
            </div>
          )}

          <h3 className="dash-suggestions-title">Suggested Projects</h3>
          <div className="dash-suggestion-list">
            {suggestions.length === 0 ? (
              <p className="dash-empty">You've added them all — nice work.</p>
            ) : (
              suggestions.map((s) => (
                <div className="dash-suggestion" key={s.name}>
                  <div>
                    <span className="dash-suggestion-name">{s.name}</span>
                    <span className="dash-lab-tag">{LABS[s.lab].label}</span>
                  </div>
                  <button
                    className="dash-add-suggestion-btn"
                    onClick={() => addSuggestion(s.name, s.lab)}
                  >
                    <Plus size={13} /> Add
                  </button>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="dash-activity">
          <h2>Recent Activity</h2>
          {activity.length === 0 ? (
            <p className="dash-empty">No activity yet — complete a lab to see it here.</p>
          ) : (
            <ul className="dash-activity-list">
              {activity.map((a) => (
                <li key={a.id}>
                  <span className="dash-activity-dot" />
                  <span>
                    <strong>{a.name}</strong> completed
                    <br />
                    <span className="dash-activity-time">{a.time}</span>
                  </span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>

      {showAddModal && (
        <div className="dash-modal-overlay" onClick={() => setShowAddModal(false)}>
          <div className="dash-modal-box" onClick={(e) => e.stopPropagation()}>
            <button
              className="dash-modal-close"
              onClick={() => setShowAddModal(false)}
              aria-label="Close"
            >
              <X size={18} />
            </button>
            <h2>Add Project</h2>
            <form onSubmit={handleAddSubmit} className="dash-add-form">
              <label htmlFor="projectName">Project name</label>
              <input
                id="projectName"
                type="text"
                value={newName}
                onChange={(e) => setNewName(e.target.value)}
                placeholder="e.g. Smart Traffic Light"
                autoFocus
                required
              />
              <label htmlFor="projectLab">Lab</label>
              <select
                id="projectLab"
                value={newLab}
                onChange={(e) => setNewLab(e.target.value as LabKey)}
              >
                {Object.entries(LABS).map(([key, lab]) => (
                  <option key={key} value={key}>
                    {lab.label}
                  </option>
                ))}
              </select>
              <button type="submit" className="dash-btn-cta dash-modal-submit">
                Add Project
              </button>
            </form>
          </div>
        </div>
      )}
    </main>
  )
}
